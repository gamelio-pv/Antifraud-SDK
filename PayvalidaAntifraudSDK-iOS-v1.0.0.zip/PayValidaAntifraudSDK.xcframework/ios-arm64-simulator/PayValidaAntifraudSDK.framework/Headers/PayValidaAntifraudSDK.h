#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class PVASDKAcquirer, PVASDKAcquirerCompanion, PVASDKCardScheme, PVASDKCardholder, PVASDKCardholderAccount, PVASDKCardholderAccountCompanion, PVASDKCardholderCompanion, PVASDKCardholderData, PVASDKCardholderDataCompanion, PVASDKConfig, PVASDKCustomInterval, PVASDKEnvironment, PVASDKFormData, PVASDKKotlinAbstractCoroutineContextElement, PVASDKKotlinAbstractCoroutineContextKey<B, E>, PVASDKKotlinArray<T>, PVASDKKotlinByteArray, PVASDKKotlinByteIterator, PVASDKKotlinCancellationException, PVASDKKotlinEnum<E>, PVASDKKotlinEnumCompanion, PVASDKKotlinException, PVASDKKotlinIllegalStateException, PVASDKKotlinKTypeProjection, PVASDKKotlinKTypeProjectionCompanion, PVASDKKotlinKVariance, PVASDKKotlinNothing, PVASDKKotlinRuntimeException, PVASDKKotlinThrowable, PVASDKKotlinUnit, PVASDKKotlinx_coroutines_coreCoroutineDispatcher, PVASDKKotlinx_coroutines_coreCoroutineDispatcherKey, PVASDKKotlinx_io_coreBuffer, PVASDKKotlinx_serialization_coreSerialKind, PVASDKKotlinx_serialization_coreSerializersModule, PVASDKKountConfig, PVASDKKountData, PVASDKKtor_client_coreHttpClient, PVASDKKtor_client_coreHttpClientCall, PVASDKKtor_client_coreHttpClientCallCompanion, PVASDKKtor_client_coreHttpClientConfig<T>, PVASDKKtor_client_coreHttpClientEngineConfig, PVASDKKtor_client_coreHttpReceivePipeline, PVASDKKtor_client_coreHttpReceivePipelinePhases, PVASDKKtor_client_coreHttpRequestBuilder, PVASDKKtor_client_coreHttpRequestBuilderCompanion, PVASDKKtor_client_coreHttpRequestData, PVASDKKtor_client_coreHttpRequestPipeline, PVASDKKtor_client_coreHttpRequestPipelinePhases, PVASDKKtor_client_coreHttpResponse, PVASDKKtor_client_coreHttpResponseContainer, PVASDKKtor_client_coreHttpResponseData, PVASDKKtor_client_coreHttpResponsePipeline, PVASDKKtor_client_coreHttpResponsePipelinePhases, PVASDKKtor_client_coreHttpSendPipeline, PVASDKKtor_client_coreHttpSendPipelinePhases, PVASDKKtor_client_coreProxyConfig, PVASDKKtor_eventsEventDefinition<T>, PVASDKKtor_eventsEvents, PVASDKKtor_httpContentType, PVASDKKtor_httpContentTypeCompanion, PVASDKKtor_httpHeaderValueParam, PVASDKKtor_httpHeaderValueWithParameters, PVASDKKtor_httpHeaderValueWithParametersCompanion, PVASDKKtor_httpHeadersBuilder, PVASDKKtor_httpHttpMethod, PVASDKKtor_httpHttpMethodCompanion, PVASDKKtor_httpHttpProtocolVersion, PVASDKKtor_httpHttpProtocolVersionCompanion, PVASDKKtor_httpHttpStatusCode, PVASDKKtor_httpHttpStatusCodeCompanion, PVASDKKtor_httpOutgoingContent, PVASDKKtor_httpURLBuilder, PVASDKKtor_httpURLBuilderCompanion, PVASDKKtor_httpURLProtocol, PVASDKKtor_httpURLProtocolCompanion, PVASDKKtor_httpUrl, PVASDKKtor_httpUrlCompanion, PVASDKKtor_utilsAttributeKey<T>, PVASDKKtor_utilsGMTDate, PVASDKKtor_utilsGMTDateCompanion, PVASDKKtor_utilsMonth, PVASDKKtor_utilsMonthCompanion, PVASDKKtor_utilsPipeline<TSubject, TContext>, PVASDKKtor_utilsPipelinePhase, PVASDKKtor_utilsStringValuesBuilderImpl, PVASDKKtor_utilsTypeInfo, PVASDKKtor_utilsWeekDay, PVASDKKtor_utilsWeekDayCompanion, PVASDKMethodResponse, PVASDKMethodResponseData, PVASDKMobilePhone, PVASDKMobilePhoneCompanion, PVASDKThreeDSAuthenticationRequest, PVASDKThreeDSAuthenticationRequestCompanion, PVASDKThreeDSBrowserInformation, PVASDKThreeDSBrowserInformationCompanion, PVASDKThreeDSIFrameValidatorApiResponse, PVASDKThreeDSIFrameValidatorApiResponseCompanion, PVASDKThreeDSValidatorApiResponse, PVASDKThreeDSValidatorApiResponseCompanion, PVASDKThreeDSValidatorRequest, PVASDKThreeDSValidatorRequestCompanion, PVASDKThreeDSValidatorResponseData, PVASDKThreeDSValidatorResponseDataCompanion, PVASDKThreeDSVersioningRequest, PVASDKThreeDSVersioningRequestCompanion;

@protocol PVASDKKotlinAnnotation, PVASDKKotlinAutoCloseable, PVASDKKotlinComparable, PVASDKKotlinContinuation, PVASDKKotlinContinuationInterceptor, PVASDKKotlinCoroutineContext, PVASDKKotlinCoroutineContextElement, PVASDKKotlinCoroutineContextKey, PVASDKKotlinFunction, PVASDKKotlinIterator, PVASDKKotlinKAnnotatedElement, PVASDKKotlinKClass, PVASDKKotlinKClassifier, PVASDKKotlinKDeclarationContainer, PVASDKKotlinKType, PVASDKKotlinMapEntry, PVASDKKotlinSequence, PVASDKKotlinSuspendFunction0, PVASDKKotlinSuspendFunction2, PVASDKKotlinx_coroutines_coreChildHandle, PVASDKKotlinx_coroutines_coreChildJob, PVASDKKotlinx_coroutines_coreCoroutineScope, PVASDKKotlinx_coroutines_coreDisposableHandle, PVASDKKotlinx_coroutines_coreJob, PVASDKKotlinx_coroutines_coreParentJob, PVASDKKotlinx_coroutines_coreRunnable, PVASDKKotlinx_coroutines_coreSelectClause, PVASDKKotlinx_coroutines_coreSelectClause0, PVASDKKotlinx_coroutines_coreSelectInstance, PVASDKKotlinx_io_coreRawSink, PVASDKKotlinx_io_coreRawSource, PVASDKKotlinx_io_coreSink, PVASDKKotlinx_io_coreSource, PVASDKKotlinx_serialization_coreCompositeDecoder, PVASDKKotlinx_serialization_coreCompositeEncoder, PVASDKKotlinx_serialization_coreDecoder, PVASDKKotlinx_serialization_coreDeserializationStrategy, PVASDKKotlinx_serialization_coreEncoder, PVASDKKotlinx_serialization_coreKSerializer, PVASDKKotlinx_serialization_coreSerialDescriptor, PVASDKKotlinx_serialization_coreSerializationStrategy, PVASDKKotlinx_serialization_coreSerializersModuleCollector, PVASDKKtor_client_coreHttpClientEngine, PVASDKKtor_client_coreHttpClientEngineCapability, PVASDKKtor_client_coreHttpClientPlugin, PVASDKKtor_client_coreHttpRequest, PVASDKKtor_httpHeaders, PVASDKKtor_httpHttpMessage, PVASDKKtor_httpHttpMessageBuilder, PVASDKKtor_httpParameters, PVASDKKtor_httpParametersBuilder, PVASDKKtor_ioByteReadChannel, PVASDKKtor_ioCloseable, PVASDKKtor_ioJvmSerializable, PVASDKKtor_utilsAttributes, PVASDKKtor_utilsStringValues, PVASDKKtor_utilsStringValuesBuilder;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface PVASDKBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface PVASDKBase (PVASDKBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface PVASDKMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface PVASDKMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorPVASDKKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface PVASDKNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface PVASDKByte : PVASDKNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface PVASDKUByte : PVASDKNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface PVASDKShort : PVASDKNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface PVASDKUShort : PVASDKNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface PVASDKInt : PVASDKNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface PVASDKUInt : PVASDKNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface PVASDKLong : PVASDKNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface PVASDKULong : PVASDKNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface PVASDKFloat : PVASDKNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface PVASDKDouble : PVASDKNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface PVASDKBoolean : PVASDKNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Config")))
@interface PVASDKConfig : PVASDKBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl env:(NSString *)env kountConfig:(PVASDKKountConfig *)kountConfig __attribute__((swift_name("init(baseUrl:env:kountConfig:)"))) __attribute__((objc_designated_initializer));
- (PVASDKConfig *)doCopyBaseUrl:(NSString *)baseUrl env:(NSString *)env kountConfig:(PVASDKKountConfig *)kountConfig __attribute__((swift_name("doCopy(baseUrl:env:kountConfig:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *baseUrl __attribute__((swift_name("baseUrl")));
@property (readonly) NSString *env __attribute__((swift_name("env")));
@property (readonly) PVASDKKountConfig *kountConfig __attribute__((swift_name("kountConfig")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol PVASDKKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface PVASDKKotlinEnum<E> : PVASDKBase <PVASDKKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Environment")))
@interface PVASDKEnvironment : PVASDKKotlinEnum<PVASDKEnvironment *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PVASDKEnvironment *production __attribute__((swift_name("production")));
@property (class, readonly) PVASDKEnvironment *sandbox __attribute__((swift_name("sandbox")));
+ (PVASDKKotlinArray<PVASDKEnvironment *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PVASDKEnvironment *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PayvalidaAntifraudSdk")))
@interface PVASDKPayvalidaAntifraudSdk : PVASDKBase
- (instancetype)initWithEnv:(PVASDKEnvironment *)env __attribute__((swift_name("init(env:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startKountValidatorData:(PVASDKKountData *)data completionHandler:(void (^)(PVASDKMethodResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startKountValidator(data:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)startThreeDSValidatorData:(PVASDKFormData *)data completionHandler:(void (^)(PVASDKMethodResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("startThreeDSValidator(data:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ApiClient")))
@interface PVASDKApiClient : PVASDKBase
- (instancetype)initWithBaseUrl:(NSString *)baseUrl __attribute__((swift_name("init(baseUrl:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)postValidatorRequest:(PVASDKThreeDSValidatorRequest *)request token:(NSString *)token completionHandler:(void (^)(PVASDKKtor_client_coreHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("postValidator(request:token:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)shortPollIframeToken:(NSString *)token completionHandler:(void (^)(PVASDKBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("shortPollIframe(token:completionHandler:)")));
@property (readonly) PVASDKKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IOSChallengeHandler")))
@interface PVASDKIOSChallengeHandler : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)removeChallenge __attribute__((swift_name("removeChallenge()")));
- (void)showChallengeUrl:(NSString *)url __attribute__((swift_name("showChallenge(url:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KountHelper")))
@interface PVASDKKountHelper : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString * _Nullable)collectData __attribute__((swift_name("collectData()")));
- (void)setupConfig:(PVASDKKountConfig *)config __attribute__((swift_name("setup(config:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Acquirer")))
@interface PVASDKAcquirer : PVASDKBase
- (instancetype)initWithAcquirerBin:(NSString *)acquirerBin __attribute__((swift_name("init(acquirerBin:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKAcquirerCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKAcquirer *)doCopyAcquirerBin:(NSString *)acquirerBin __attribute__((swift_name("doCopy(acquirerBin:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *acquirerBin __attribute__((swift_name("acquirerBin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Acquirer.Companion")))
@interface PVASDKAcquirerCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKAcquirerCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardScheme")))
@interface PVASDKCardScheme : PVASDKKotlinEnum<PVASDKCardScheme *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PVASDKCardScheme *visa __attribute__((swift_name("visa")));
@property (class, readonly) PVASDKCardScheme *mastercard __attribute__((swift_name("mastercard")));
@property (class, readonly) PVASDKCardScheme *amex __attribute__((swift_name("amex")));
+ (PVASDKKotlinArray<PVASDKCardScheme *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PVASDKCardScheme *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cardholder")))
@interface PVASDKCardholder : PVASDKBase
- (instancetype)initWithBillAddrCity:(NSString *)billAddrCity billAddrCountry:(NSString *)billAddrCountry billAddrLine1:(NSString *)billAddrLine1 billAddrLine2:(NSString *)billAddrLine2 billAddrLine3:(NSString *)billAddrLine3 billAddrPostCode:(NSString *)billAddrPostCode billAddrState:(NSString *)billAddrState cardholderName:(NSString *)cardholderName email:(NSString *)email mobilePhone:(PVASDKMobilePhone *)mobilePhone __attribute__((swift_name("init(billAddrCity:billAddrCountry:billAddrLine1:billAddrLine2:billAddrLine3:billAddrPostCode:billAddrState:cardholderName:email:mobilePhone:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKCardholderCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKCardholder *)doCopyBillAddrCity:(NSString *)billAddrCity billAddrCountry:(NSString *)billAddrCountry billAddrLine1:(NSString *)billAddrLine1 billAddrLine2:(NSString *)billAddrLine2 billAddrLine3:(NSString *)billAddrLine3 billAddrPostCode:(NSString *)billAddrPostCode billAddrState:(NSString *)billAddrState cardholderName:(NSString *)cardholderName email:(NSString *)email mobilePhone:(PVASDKMobilePhone *)mobilePhone __attribute__((swift_name("doCopy(billAddrCity:billAddrCountry:billAddrLine1:billAddrLine2:billAddrLine3:billAddrPostCode:billAddrState:cardholderName:email:mobilePhone:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *billAddrCity __attribute__((swift_name("billAddrCity")));
@property (readonly) NSString *billAddrCountry __attribute__((swift_name("billAddrCountry")));
@property (readonly) NSString *billAddrLine1 __attribute__((swift_name("billAddrLine1")));
@property (readonly) NSString *billAddrLine2 __attribute__((swift_name("billAddrLine2")));
@property (readonly) NSString *billAddrLine3 __attribute__((swift_name("billAddrLine3")));
@property (readonly) NSString *billAddrPostCode __attribute__((swift_name("billAddrPostCode")));
@property (readonly) NSString *billAddrState __attribute__((swift_name("billAddrState")));
@property (readonly) NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) PVASDKMobilePhone *mobilePhone __attribute__((swift_name("mobilePhone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Cardholder.Companion")))
@interface PVASDKCardholderCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKCardholderCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardholderAccount")))
@interface PVASDKCardholderAccount : PVASDKBase
- (instancetype)initWithAcctNumber:(NSString *)acctNumber cardExpiryDate:(NSString *)cardExpiryDate schemeID:(PVASDKCardScheme *)schemeID __attribute__((swift_name("init(acctNumber:cardExpiryDate:schemeID:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKCardholderAccountCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKCardholderAccount *)doCopyAcctNumber:(NSString *)acctNumber cardExpiryDate:(NSString *)cardExpiryDate schemeID:(PVASDKCardScheme *)schemeID __attribute__((swift_name("doCopy(acctNumber:cardExpiryDate:schemeID:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *acctNumber __attribute__((swift_name("acctNumber")));
@property (readonly) NSString *cardExpiryDate __attribute__((swift_name("cardExpiryDate")));
@property (readonly) PVASDKCardScheme *schemeID __attribute__((swift_name("schemeID")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardholderAccount.Companion")))
@interface PVASDKCardholderAccountCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKCardholderAccountCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardholderData")))
@interface PVASDKCardholderData : PVASDKBase
- (instancetype)initWithName:(NSString *)name typeDi:(NSString *)typeDi di:(NSString *)di phoneNumber:(NSString *)phoneNumber email:(NSString *)email __attribute__((swift_name("init(name:typeDi:di:phoneNumber:email:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKCardholderDataCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKCardholderData *)doCopyName:(NSString *)name typeDi:(NSString *)typeDi di:(NSString *)di phoneNumber:(NSString *)phoneNumber email:(NSString *)email __attribute__((swift_name("doCopy(name:typeDi:di:phoneNumber:email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *di __attribute__((swift_name("di")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *phoneNumber __attribute__((swift_name("phoneNumber")));
@property (readonly) NSString *typeDi __attribute__((swift_name("typeDi")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardholderData.Companion")))
@interface PVASDKCardholderDataCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKCardholderDataCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FormData")))
@interface PVASDKFormData : PVASDKBase
- (instancetype)initWithBillAddrCity:(NSString *)billAddrCity billAddrCountry:(NSString *)billAddrCountry billAddrLine1:(NSString *)billAddrLine1 billAddrLine2:(NSString *)billAddrLine2 billAddrPostCode:(NSString *)billAddrPostCode billAddrState:(NSString *)billAddrState cardNumber:(NSString *)cardNumber instalments:(int32_t)instalments cvv:(NSString *)cvv di:(NSString *)di expirationMonth:(NSString *)expirationMonth expirationYear:(NSString *)expirationYear lastName:(NSString *)lastName name:(NSString *)name token:(NSString *)token typeDI:(NSString *)typeDI cellPhone:(NSString *)cellPhone email:(NSString *)email __attribute__((swift_name("init(billAddrCity:billAddrCountry:billAddrLine1:billAddrLine2:billAddrPostCode:billAddrState:cardNumber:instalments:cvv:di:expirationMonth:expirationYear:lastName:name:token:typeDI:cellPhone:email:)"))) __attribute__((objc_designated_initializer));
- (PVASDKFormData *)doCopyBillAddrCity:(NSString *)billAddrCity billAddrCountry:(NSString *)billAddrCountry billAddrLine1:(NSString *)billAddrLine1 billAddrLine2:(NSString *)billAddrLine2 billAddrPostCode:(NSString *)billAddrPostCode billAddrState:(NSString *)billAddrState cardNumber:(NSString *)cardNumber instalments:(int32_t)instalments cvv:(NSString *)cvv di:(NSString *)di expirationMonth:(NSString *)expirationMonth expirationYear:(NSString *)expirationYear lastName:(NSString *)lastName name:(NSString *)name token:(NSString *)token typeDI:(NSString *)typeDI cellPhone:(NSString *)cellPhone email:(NSString *)email __attribute__((swift_name("doCopy(billAddrCity:billAddrCountry:billAddrLine1:billAddrLine2:billAddrPostCode:billAddrState:cardNumber:instalments:cvv:di:expirationMonth:expirationYear:lastName:name:token:typeDI:cellPhone:email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *billAddrCity __attribute__((swift_name("billAddrCity")));
@property (readonly) NSString *billAddrCountry __attribute__((swift_name("billAddrCountry")));
@property (readonly) NSString *billAddrLine1 __attribute__((swift_name("billAddrLine1")));
@property (readonly) NSString *billAddrLine2 __attribute__((swift_name("billAddrLine2")));
@property (readonly) NSString *billAddrPostCode __attribute__((swift_name("billAddrPostCode")));
@property (readonly) NSString *billAddrState __attribute__((swift_name("billAddrState")));
@property (readonly) NSString *cardNumber __attribute__((swift_name("cardNumber")));
@property (readonly) NSString *cellPhone __attribute__((swift_name("cellPhone")));
@property (readonly) NSString *cvv __attribute__((swift_name("cvv")));
@property (readonly) NSString *di __attribute__((swift_name("di")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString *expirationMonth __attribute__((swift_name("expirationMonth")));
@property (readonly) NSString *expirationYear __attribute__((swift_name("expirationYear")));
@property (readonly) int32_t instalments __attribute__((swift_name("instalments")));
@property (readonly) NSString *lastName __attribute__((swift_name("lastName")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *typeDI __attribute__((swift_name("typeDI")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KountConfig")))
@interface PVASDKKountConfig : PVASDKBase
- (instancetype)initWithClientID:(int32_t)clientID hostname:(NSString *)hostname isSinglePageApp:(BOOL)isSinglePageApp environment:(PVASDKEnvironment *)environment isDebugEnabled:(BOOL)isDebugEnabled __attribute__((swift_name("init(clientID:hostname:isSinglePageApp:environment:isDebugEnabled:)"))) __attribute__((objc_designated_initializer));
- (PVASDKKountConfig *)doCopyClientID:(int32_t)clientID hostname:(NSString *)hostname isSinglePageApp:(BOOL)isSinglePageApp environment:(PVASDKEnvironment *)environment isDebugEnabled:(BOOL)isDebugEnabled __attribute__((swift_name("doCopy(clientID:hostname:isSinglePageApp:environment:isDebugEnabled:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t clientID __attribute__((swift_name("clientID")));
@property (readonly) PVASDKEnvironment *environment __attribute__((swift_name("environment")));
@property (readonly) NSString *hostname __attribute__((swift_name("hostname")));
@property (readonly) BOOL isDebugEnabled __attribute__((swift_name("isDebugEnabled")));
@property (readonly) BOOL isSinglePageApp __attribute__((swift_name("isSinglePageApp")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KountData")))
@interface PVASDKKountData : PVASDKBase
- (instancetype)initWithToken:(NSString *)token franchise:(NSString * _Nullable)franchise __attribute__((swift_name("init(token:franchise:)"))) __attribute__((objc_designated_initializer));
- (PVASDKKountData *)doCopyToken:(NSString *)token franchise:(NSString * _Nullable)franchise __attribute__((swift_name("doCopy(token:franchise:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable franchise __attribute__((swift_name("franchise")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MethodResponse")))
@interface PVASDKMethodResponse : PVASDKBase
- (instancetype)initWithIsApproved:(BOOL)isApproved error:(NSString * _Nullable)error data:(PVASDKMethodResponseData * _Nullable)data __attribute__((swift_name("init(isApproved:error:data:)"))) __attribute__((objc_designated_initializer));
- (PVASDKMethodResponse *)doCopyIsApproved:(BOOL)isApproved error:(NSString * _Nullable)error data:(PVASDKMethodResponseData * _Nullable)data __attribute__((swift_name("doCopy(isApproved:error:data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKMethodResponseData * _Nullable data __attribute__((swift_name("data")));
@property (readonly) NSString * _Nullable error __attribute__((swift_name("error")));
@property (readonly) BOOL isApproved __attribute__((swift_name("isApproved")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MethodResponseData")))
@interface PVASDKMethodResponseData : PVASDKBase
- (instancetype)initWithKountSessiontId:(NSString *)kountSessiontId __attribute__((swift_name("init(kountSessiontId:)"))) __attribute__((objc_designated_initializer));
- (PVASDKMethodResponseData *)doCopyKountSessiontId:(NSString *)kountSessiontId __attribute__((swift_name("doCopy(kountSessiontId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *kountSessiontId __attribute__((swift_name("kountSessiontId")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobilePhone")))
@interface PVASDKMobilePhone : PVASDKBase
- (instancetype)initWithCc:(NSString *)cc subscriber:(NSString *)subscriber __attribute__((swift_name("init(cc:subscriber:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKMobilePhoneCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKMobilePhone *)doCopyCc:(NSString *)cc subscriber:(NSString *)subscriber __attribute__((swift_name("doCopy(cc:subscriber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *cc __attribute__((swift_name("cc")));
@property (readonly) NSString *subscriber __attribute__((swift_name("subscriber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MobilePhone.Companion")))
@interface PVASDKMobilePhoneCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKMobilePhoneCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSAuthenticationRequest")))
@interface PVASDKThreeDSAuthenticationRequest : PVASDKBase
- (instancetype)initWithBrowserInformation:(PVASDKThreeDSBrowserInformation *)browserInformation cardholder:(PVASDKCardholder *)cardholder cardholderAccount:(PVASDKCardholderAccount *)cardholderAccount cardholderDocument:(NSString *)cardholderDocument acquirer:(PVASDKAcquirer *)acquirer __attribute__((swift_name("init(browserInformation:cardholder:cardholderAccount:cardholderDocument:acquirer:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSAuthenticationRequestCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSAuthenticationRequest *)doCopyBrowserInformation:(PVASDKThreeDSBrowserInformation *)browserInformation cardholder:(PVASDKCardholder *)cardholder cardholderAccount:(PVASDKCardholderAccount *)cardholderAccount cardholderDocument:(NSString *)cardholderDocument acquirer:(PVASDKAcquirer *)acquirer __attribute__((swift_name("doCopy(browserInformation:cardholder:cardholderAccount:cardholderDocument:acquirer:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKAcquirer *acquirer __attribute__((swift_name("acquirer")));
@property (readonly) PVASDKThreeDSBrowserInformation *browserInformation __attribute__((swift_name("browserInformation")));
@property (readonly) PVASDKCardholder *cardholder __attribute__((swift_name("cardholder")));
@property (readonly) PVASDKCardholderAccount *cardholderAccount __attribute__((swift_name("cardholderAccount")));
@property (readonly) NSString *cardholderDocument __attribute__((swift_name("cardholderDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSAuthenticationRequest.Companion")))
@interface PVASDKThreeDSAuthenticationRequestCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSAuthenticationRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSBrowserInformation")))
@interface PVASDKThreeDSBrowserInformation : PVASDKBase
- (instancetype)initWithBrowserJavaEnabled:(BOOL)browserJavaEnabled browserUserAgent:(NSString *)browserUserAgent browserLanguage:(NSString *)browserLanguage browserColorDepth:(NSString *)browserColorDepth browserScreenWidth:(int32_t)browserScreenWidth browserScreenHeight:(int32_t)browserScreenHeight browserTZ:(int32_t)browserTZ browserIP:(NSString * _Nullable)browserIP challengeWindowSize:(NSString *)challengeWindowSize __attribute__((swift_name("init(browserJavaEnabled:browserUserAgent:browserLanguage:browserColorDepth:browserScreenWidth:browserScreenHeight:browserTZ:browserIP:challengeWindowSize:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSBrowserInformationCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSBrowserInformation *)doCopyBrowserJavaEnabled:(BOOL)browserJavaEnabled browserUserAgent:(NSString *)browserUserAgent browserLanguage:(NSString *)browserLanguage browserColorDepth:(NSString *)browserColorDepth browserScreenWidth:(int32_t)browserScreenWidth browserScreenHeight:(int32_t)browserScreenHeight browserTZ:(int32_t)browserTZ browserIP:(NSString * _Nullable)browserIP challengeWindowSize:(NSString *)challengeWindowSize __attribute__((swift_name("doCopy(browserJavaEnabled:browserUserAgent:browserLanguage:browserColorDepth:browserScreenWidth:browserScreenHeight:browserTZ:browserIP:challengeWindowSize:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *browserColorDepth __attribute__((swift_name("browserColorDepth")));
@property (readonly) NSString * _Nullable browserIP __attribute__((swift_name("browserIP")));
@property (readonly) BOOL browserJavaEnabled __attribute__((swift_name("browserJavaEnabled")));
@property (readonly) NSString *browserLanguage __attribute__((swift_name("browserLanguage")));
@property (readonly) int32_t browserScreenHeight __attribute__((swift_name("browserScreenHeight")));
@property (readonly) int32_t browserScreenWidth __attribute__((swift_name("browserScreenWidth")));
@property (readonly) int32_t browserTZ __attribute__((swift_name("browserTZ")));
@property (readonly) NSString *browserUserAgent __attribute__((swift_name("browserUserAgent")));
@property (readonly) NSString *challengeWindowSize __attribute__((swift_name("challengeWindowSize")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSBrowserInformation.Companion")))
@interface PVASDKThreeDSBrowserInformationCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSBrowserInformationCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSIFrameValidatorApiResponse")))
@interface PVASDKThreeDSIFrameValidatorApiResponse : PVASDKBase
- (instancetype)initWithCODE:(NSString *)CODE DESC:(NSString *)DESC __attribute__((swift_name("init(CODE:DESC:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSIFrameValidatorApiResponseCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSIFrameValidatorApiResponse *)doCopyCODE:(NSString *)CODE DESC:(NSString *)DESC __attribute__((swift_name("doCopy(CODE:DESC:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *CODE __attribute__((swift_name("CODE")));
@property (readonly) NSString *DESC __attribute__((swift_name("DESC")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSIFrameValidatorApiResponse.Companion")))
@interface PVASDKThreeDSIFrameValidatorApiResponseCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSIFrameValidatorApiResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorApiResponse")))
@interface PVASDKThreeDSValidatorApiResponse : PVASDKBase
- (instancetype)initWithDATA:(PVASDKThreeDSValidatorResponseData * _Nullable)DATA CODE:(NSString *)CODE DESC:(NSString *)DESC __attribute__((swift_name("init(DATA:CODE:DESC:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSValidatorApiResponseCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSValidatorApiResponse *)doCopyDATA:(PVASDKThreeDSValidatorResponseData * _Nullable)DATA CODE:(NSString *)CODE DESC:(NSString *)DESC __attribute__((swift_name("doCopy(DATA:CODE:DESC:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *CODE __attribute__((swift_name("CODE")));
@property (readonly) PVASDKThreeDSValidatorResponseData * _Nullable DATA __attribute__((swift_name("DATA")));
@property (readonly) NSString *DESC __attribute__((swift_name("DESC")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorApiResponse.Companion")))
@interface PVASDKThreeDSValidatorApiResponseCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSValidatorApiResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorRequest")))
@interface PVASDKThreeDSValidatorRequest : PVASDKBase
- (instancetype)initWithThreeDSVersioningRequest:(PVASDKThreeDSVersioningRequest *)threeDSVersioningRequest threeDSAuthenticationRequest:(PVASDKThreeDSAuthenticationRequest *)threeDSAuthenticationRequest cardholderData:(PVASDKCardholderData * _Nullable)cardholderData __attribute__((swift_name("init(threeDSVersioningRequest:threeDSAuthenticationRequest:cardholderData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSValidatorRequestCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSValidatorRequest *)doCopyThreeDSVersioningRequest:(PVASDKThreeDSVersioningRequest *)threeDSVersioningRequest threeDSAuthenticationRequest:(PVASDKThreeDSAuthenticationRequest *)threeDSAuthenticationRequest cardholderData:(PVASDKCardholderData * _Nullable)cardholderData __attribute__((swift_name("doCopy(threeDSVersioningRequest:threeDSAuthenticationRequest:cardholderData:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKCardholderData * _Nullable cardholderData __attribute__((swift_name("cardholderData")));
@property (readonly) PVASDKThreeDSAuthenticationRequest *threeDSAuthenticationRequest __attribute__((swift_name("threeDSAuthenticationRequest")));
@property (readonly) PVASDKThreeDSVersioningRequest *threeDSVersioningRequest __attribute__((swift_name("threeDSVersioningRequest")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorRequest.Companion")))
@interface PVASDKThreeDSValidatorRequestCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSValidatorRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorResponseData")))
@interface PVASDKThreeDSValidatorResponseData : PVASDKBase
- (instancetype)initWithApprovedTransaction:(BOOL)approvedTransaction isChallengeRequired:(BOOL)isChallengeRequired isKountValidationRequired:(BOOL)isKountValidationRequired challengeIFrame:(NSString * _Nullable)challengeIFrame __attribute__((swift_name("init(approvedTransaction:isChallengeRequired:isKountValidationRequired:challengeIFrame:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSValidatorResponseDataCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSValidatorResponseData *)doCopyApprovedTransaction:(BOOL)approvedTransaction isChallengeRequired:(BOOL)isChallengeRequired isKountValidationRequired:(BOOL)isKountValidationRequired challengeIFrame:(NSString * _Nullable)challengeIFrame __attribute__((swift_name("doCopy(approvedTransaction:isChallengeRequired:isKountValidationRequired:challengeIFrame:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL approvedTransaction __attribute__((swift_name("approvedTransaction")));
@property (readonly) NSString * _Nullable challengeIFrame __attribute__((swift_name("challengeIFrame")));
@property (readonly) BOOL isChallengeRequired __attribute__((swift_name("isChallengeRequired")));
@property (readonly) BOOL isKountValidationRequired __attribute__((swift_name("isKountValidationRequired")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSValidatorResponseData.Companion")))
@interface PVASDKThreeDSValidatorResponseDataCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSValidatorResponseDataCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSVersioningRequest")))
@interface PVASDKThreeDSVersioningRequest : PVASDKBase
- (instancetype)initWithCardholderAccountNumber:(NSString *)cardholderAccountNumber __attribute__((swift_name("init(cardholderAccountNumber:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKThreeDSVersioningRequestCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKThreeDSVersioningRequest *)doCopyCardholderAccountNumber:(NSString *)cardholderAccountNumber __attribute__((swift_name("doCopy(cardholderAccountNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *cardholderAccountNumber __attribute__((swift_name("cardholderAccountNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ThreeDSVersioningRequest.Companion")))
@interface PVASDKThreeDSVersioningRequestCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKThreeDSVersioningRequestCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CustomInterval")))
@interface PVASDKCustomInterval : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)customInterval __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKCustomInterval *shared __attribute__((swift_name("shared")));
- (void)clearJob:(id<PVASDKKotlinx_coroutines_coreJob>)job __attribute__((swift_name("clear(job:)")));
- (void)clearAll __attribute__((swift_name("clearAll()")));
- (id<PVASDKKotlinx_coroutines_coreJob>)makeScope:(id<PVASDKKotlinx_coroutines_coreCoroutineScope>)scope func:(id<PVASDKKotlinSuspendFunction0>)func timeMillis:(int64_t)timeMillis __attribute__((swift_name("make(scope:func:timeMillis:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardValidatorKt")))
@interface PVASDKCardValidatorKt : PVASDKBase
+ (PVASDKCardScheme * _Nullable)detectCardSchemeCardNumber:(NSString *)cardNumber __attribute__((swift_name("detectCardScheme(cardNumber:)")));
@property (class, readonly) NSString *CARD_NOT_SUPPORTED __attribute__((swift_name("CARD_NOT_SUPPORTED")));
@property (class, readonly) NSString *INVALID_URL __attribute__((swift_name("INVALID_URL")));
@property (class, readonly) NSString *POP_UP_BLOCKED __attribute__((swift_name("POP_UP_BLOCKED")));
@property (class, readonly) NSString *PROCESS_WAS_NOT_FINISHED __attribute__((swift_name("PROCESS_WAS_NOT_FINISHED")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ConfigKt")))
@interface PVASDKConfigKt : PVASDKBase
@property (class, readonly) PVASDKConfig *ProductionConfig __attribute__((swift_name("ProductionConfig")));
@property (class, readonly) PVASDKConfig *SandboxConfig __attribute__((swift_name("SandboxConfig")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface PVASDKKotlinEnumCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface PVASDKKotlinArray<T> : PVASDKBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(PVASDKInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<PVASDKKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface PVASDKKotlinThrowable : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (PVASDKKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface PVASDKKotlinException : PVASDKKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface PVASDKKotlinRuntimeException : PVASDKKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface PVASDKKotlinIllegalStateException : PVASDKKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface PVASDKKotlinCancellationException : PVASDKKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol PVASDKKtor_httpHttpMessage
@required
@property (readonly) id<PVASDKKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol PVASDKKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<PVASDKKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface PVASDKKtor_client_coreHttpResponse : PVASDKBase <PVASDKKtor_httpHttpMessage, PVASDKKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<PVASDKKtor_ioByteReadChannel> rawContent __attribute__((swift_name("rawContent")));
@property (readonly) PVASDKKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) PVASDKKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="2.0")
*/
__attribute__((swift_name("KotlinAutoCloseable")))
@protocol PVASDKKotlinAutoCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol PVASDKKtor_ioCloseable <PVASDKKotlinAutoCloseable>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface PVASDKKtor_client_coreHttpClient : PVASDKBase <PVASDKKotlinx_coroutines_coreCoroutineScope, PVASDKKtor_ioCloseable>
- (instancetype)initWithEngine:(id<PVASDKKtor_client_coreHttpClientEngine>)engine userConfig:(PVASDKKtor_client_coreHttpClientConfig<PVASDKKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (PVASDKKtor_client_coreHttpClient *)configBlock:(void (^)(PVASDKKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<PVASDKKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<PVASDKKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<PVASDKKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) PVASDKKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) PVASDKKtor_eventsEvents *monitor __attribute__((swift_name("monitor")));
@property (readonly) PVASDKKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) PVASDKKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) PVASDKKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) PVASDKKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol PVASDKKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<PVASDKKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<PVASDKKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol PVASDKKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<PVASDKKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<PVASDKKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol PVASDKKotlinx_serialization_coreKSerializer <PVASDKKotlinx_serialization_coreSerializationStrategy, PVASDKKotlinx_serialization_coreDeserializationStrategy>
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol PVASDKKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<PVASDKKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<PVASDKKotlinCoroutineContextElement> _Nullable)getKey:(id<PVASDKKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<PVASDKKotlinCoroutineContext>)minusKeyKey:(id<PVASDKKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<PVASDKKotlinCoroutineContext>)plusContext:(id<PVASDKKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol PVASDKKotlinCoroutineContextElement <PVASDKKotlinCoroutineContext>
@required
@property (readonly) id<PVASDKKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol PVASDKKotlinx_coroutines_coreJob <PVASDKKotlinCoroutineContextElement>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<PVASDKKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<PVASDKKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause:(PVASDKKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (PVASDKKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<PVASDKKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(PVASDKKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (id<PVASDKKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(PVASDKKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<PVASDKKotlinx_coroutines_coreJob>)plusOther:(id<PVASDKKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<PVASDKKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<PVASDKKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
@property (readonly) id<PVASDKKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol PVASDKKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol PVASDKKotlinSuspendFunction0 <PVASDKKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol PVASDKKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol PVASDKKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<PVASDKKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol PVASDKKtor_httpHeaders <PVASDKKtor_utilsStringValues>
@required
@end

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface PVASDKKtor_client_coreHttpClientCall : PVASDKBase <PVASDKKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithClient:(PVASDKKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithClient:(PVASDKKtor_client_coreHttpClient *)client requestData:(PVASDKKtor_client_coreHttpRequestData *)requestData responseData:(PVASDKKtor_client_coreHttpResponseData *)responseData __attribute__((swift_name("init(client:requestData:responseData:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyInfo:(PVASDKKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("body(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)bodyNullableInfo:(PVASDKKtor_utilsTypeInfo *)info completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("bodyNullable(info:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<PVASDKKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) PVASDKKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@property (readonly) id<PVASDKKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property id<PVASDKKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property PVASDKKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol PVASDKKtor_ioByteReadChannel
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitContentMin:(int32_t)min completionHandler:(void (^)(PVASDKBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("awaitContent(min:completionHandler:)")));
- (void)cancelCause_:(PVASDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
@property (readonly) PVASDKKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) id<PVASDKKotlinx_io_coreSource> readBuffer __attribute__((swift_name("readBuffer")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface PVASDKKtor_utilsGMTDate : PVASDKBase <PVASDKKotlinComparable>
- (instancetype)initWithSeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(PVASDKKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(PVASDKKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("init(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(PVASDKKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (PVASDKKtor_utilsGMTDate *)doCopy __attribute__((swift_name("doCopy()")));
- (PVASDKKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(PVASDKKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(PVASDKKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) PVASDKKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) PVASDKKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface PVASDKKtor_httpHttpStatusCode : PVASDKBase <PVASDKKotlinComparable>
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(PVASDKKtor_httpHttpStatusCode *)other __attribute__((swift_name("compareTo(other:)")));
- (PVASDKKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (PVASDKKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface PVASDKKtor_httpHttpProtocolVersion : PVASDKBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol PVASDKKtor_client_coreHttpClientEngine <PVASDKKotlinx_coroutines_coreCoroutineScope, PVASDKKtor_ioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(PVASDKKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(PVASDKKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(PVASDKKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) PVASDKKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) PVASDKKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<PVASDKKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface PVASDKKtor_client_coreHttpClientEngineConfig : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property PVASDKKotlinx_coroutines_coreCoroutineDispatcher * _Nullable dispatcher __attribute__((swift_name("dispatcher")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property PVASDKKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount"))) __attribute__((unavailable("The [threadsCount] property is deprecated. Consider setting [dispatcher] instead.")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface PVASDKKtor_client_coreHttpClientConfig<T> : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (PVASDKKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(PVASDKKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installPlugin:(id<PVASDKKtor_client_coreHttpClientPlugin>)plugin configure:(void (^)(id))configure __attribute__((swift_name("install(plugin:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(PVASDKKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(PVASDKKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode"))) __attribute__((deprecated("Development mode is no longer required. The property will be removed in the future.")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol PVASDKKtor_client_coreHttpClientEngineCapability
@required
@end

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol PVASDKKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(PVASDKKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(PVASDKKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<PVASDKKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_eventsEvents")))
@interface PVASDKKtor_eventsEvents : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)raiseDefinition:(PVASDKKtor_eventsEventDefinition<id> *)definition value:(id _Nullable)value __attribute__((swift_name("raise(definition:value:)")));
- (id<PVASDKKotlinx_coroutines_coreDisposableHandle>)subscribeDefinition:(PVASDKKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("subscribe(definition:handler:)")));
- (void)unsubscribeDefinition:(PVASDKKtor_eventsEventDefinition<id> *)definition handler:(void (^)(id _Nullable))handler __attribute__((swift_name("unsubscribe(definition:handler:)")));
@end

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface PVASDKKtor_utilsPipeline<TSubject, TContext> : PVASDKBase
- (instancetype)initWithPhases:(PVASDKKotlinArray<PVASDKKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(PVASDKKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(PVASDKKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(PVASDKKtor_utilsPipelinePhase *)reference phase:(PVASDKKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(PVASDKKtor_utilsPipelinePhase *)reference phase:(PVASDKKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(PVASDKKtor_utilsPipelinePhase *)phase block:(id<PVASDKKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptorsForPhasePhase:(PVASDKKtor_utilsPipelinePhase *)phase __attribute__((swift_name("interceptorsForPhase(phase:)")));
- (void)mergeFrom:(PVASDKKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
- (void)mergePhasesFrom:(PVASDKKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("mergePhases(from:)")));
- (void)resetFromFrom:(PVASDKKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("resetFrom(from:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<PVASDKKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface PVASDKKtor_client_coreHttpReceivePipeline : PVASDKKtor_utilsPipeline<PVASDKKtor_client_coreHttpResponse *, PVASDKKotlinUnit *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(PVASDKKotlinArray<PVASDKKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(PVASDKKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface PVASDKKtor_client_coreHttpRequestPipeline : PVASDKKtor_utilsPipeline<id, PVASDKKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(PVASDKKotlinArray<PVASDKKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(PVASDKKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface PVASDKKtor_client_coreHttpResponsePipeline : PVASDKKtor_utilsPipeline<PVASDKKtor_client_coreHttpResponseContainer *, PVASDKKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(PVASDKKotlinArray<PVASDKKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(PVASDKKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface PVASDKKtor_client_coreHttpSendPipeline : PVASDKKtor_utilsPipeline<id, PVASDKKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(PVASDKKotlinArray<PVASDKKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhase:(PVASDKKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<PVASDKKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol PVASDKKotlinx_serialization_coreEncoder
@required
- (id<PVASDKKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<PVASDKKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<PVASDKKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<PVASDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<PVASDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) PVASDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol PVASDKKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<PVASDKKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<PVASDKKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<PVASDKKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) PVASDKKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol PVASDKKotlinx_serialization_coreDecoder
@required
- (id<PVASDKKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<PVASDKKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (PVASDKKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) PVASDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol PVASDKKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol PVASDKKotlinx_coroutines_coreChildHandle <PVASDKKotlinx_coroutines_coreDisposableHandle>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (BOOL)childCancelledCause:(PVASDKKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
@property (readonly) id<PVASDKKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol PVASDKKotlinx_coroutines_coreChildJob <PVASDKKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)parentCancelledParentJob:(id<PVASDKKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end

__attribute__((swift_name("KotlinSequence")))
@protocol PVASDKKotlinSequence
@required
- (id<PVASDKKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause")))
@protocol PVASDKKotlinx_coroutines_coreSelectClause
@required
@property (readonly) id clauseObject __attribute__((swift_name("clauseObject")));
@property (readonly) PVASDKKotlinUnit *(^(^ _Nullable onCancellationConstructor)(id<PVASDKKotlinx_coroutines_coreSelectInstance>, id _Nullable, id _Nullable))(PVASDKKotlinThrowable *, id _Nullable, id<PVASDKKotlinCoroutineContext>) __attribute__((swift_name("onCancellationConstructor")));
@property (readonly) id _Nullable (^processResFunc)(id, id _Nullable, id _Nullable) __attribute__((swift_name("processResFunc")));
@property (readonly) void (^regFunc)(id, id<PVASDKKotlinx_coroutines_coreSelectInstance>, id _Nullable) __attribute__((swift_name("regFunc")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol PVASDKKotlinx_coroutines_coreSelectClause0 <PVASDKKotlinx_coroutines_coreSelectClause>
@required
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol PVASDKKotlinCoroutineContextKey
@required
@end

__attribute__((swift_name("KotlinMapEntry")))
@protocol PVASDKKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface PVASDKKtor_client_coreHttpRequestData : PVASDKBase
- (instancetype)initWithUrl:(PVASDKKtor_httpUrl *)url method:(PVASDKKtor_httpHttpMethod *)method headers:(id<PVASDKKtor_httpHeaders>)headers body:(PVASDKKtor_httpOutgoingContent *)body executionContext:(id<PVASDKKotlinx_coroutines_coreJob>)executionContext attributes:(id<PVASDKKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<PVASDKKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) PVASDKKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<PVASDKKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<PVASDKKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) PVASDKKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) PVASDKKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface PVASDKKtor_client_coreHttpResponseData : PVASDKBase
- (instancetype)initWithStatusCode:(PVASDKKtor_httpHttpStatusCode *)statusCode requestTime:(PVASDKKtor_utilsGMTDate *)requestTime headers:(id<PVASDKKtor_httpHeaders>)headers version:(PVASDKKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<PVASDKKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<PVASDKKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<PVASDKKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) PVASDKKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) PVASDKKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface PVASDKKtor_client_coreHttpClientCallCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsTypeInfo")))
@interface PVASDKKtor_utilsTypeInfo : PVASDKBase
- (instancetype)initWithType:(id<PVASDKKotlinKClass>)type kotlinType:(id<PVASDKKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:kotlinType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithType:(id<PVASDKKotlinKClass>)type reifiedType:(id<PVASDKKotlinKType>)reifiedType kotlinType:(id<PVASDKKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use constructor without reifiedType parameter.")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<PVASDKKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<PVASDKKotlinKClass> type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol PVASDKKtor_client_coreHttpRequest <PVASDKKtor_httpHttpMessage, PVASDKKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) PVASDKKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) PVASDKKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) PVASDKKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) PVASDKKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSource")))
@protocol PVASDKKotlinx_io_coreRawSource <PVASDKKotlinAutoCloseable>
@required
- (int64_t)readAtMostToSink:(PVASDKKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSource")))
@protocol PVASDKKotlinx_io_coreSource <PVASDKKotlinx_io_coreRawSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (id<PVASDKKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int32_t)readAtMostToSink:(PVASDKKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<PVASDKKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (int64_t)transferToSink:(id<PVASDKKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) PVASDKKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface PVASDKKtor_utilsWeekDay : PVASDKKotlinEnum<PVASDKKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) PVASDKKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (PVASDKKotlinArray<PVASDKKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PVASDKKtor_utilsWeekDay *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface PVASDKKtor_utilsMonth : PVASDKKotlinEnum<PVASDKKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) PVASDKKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) PVASDKKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) PVASDKKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) PVASDKKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) PVASDKKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) PVASDKKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) PVASDKKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) PVASDKKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) PVASDKKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) PVASDKKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) PVASDKKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) PVASDKKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (PVASDKKotlinArray<PVASDKKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PVASDKKtor_utilsMonth *> *entries __attribute__((swift_name("entries")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface PVASDKKtor_utilsGMTDateCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) PVASDKKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface PVASDKKtor_httpHttpStatusCodeCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *TooEarly __attribute__((swift_name("TooEarly")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) PVASDKKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<PVASDKKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface PVASDKKtor_httpHttpProtocolVersionCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (PVASDKKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) PVASDKKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface PVASDKKotlinAbstractCoroutineContextElement : PVASDKBase <PVASDKKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<PVASDKKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<PVASDKKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol PVASDKKotlinContinuationInterceptor <PVASDKKotlinCoroutineContextElement>
@required
- (id<PVASDKKotlinContinuation>)interceptContinuationContinuation:(id<PVASDKKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<PVASDKKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface PVASDKKotlinx_coroutines_coreCoroutineDispatcher : PVASDKKotlinAbstractCoroutineContextElement <PVASDKKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<PVASDKKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<PVASDKKotlinCoroutineContext>)context block:(id<PVASDKKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (void)dispatchYieldContext:(id<PVASDKKotlinCoroutineContext>)context block:(id<PVASDKKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<PVASDKKotlinContinuation>)interceptContinuationContinuation:(id<PVASDKKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<PVASDKKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (PVASDKKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism name:(NSString * _Nullable)name __attribute__((swift_name("limitedParallelism(parallelism:name:)")));
- (PVASDKKotlinx_coroutines_coreCoroutineDispatcher *)plusOther_:(PVASDKKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<PVASDKKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface PVASDKKtor_client_coreProxyConfig : PVASDKBase
- (instancetype)initWithUrl:(PVASDKKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKKtor_httpUrl *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Ktor_client_coreHttpClientPlugin")))
@protocol PVASDKKtor_client_coreHttpClientPlugin
@required
- (void)installPlugin:(id)plugin scope:(PVASDKKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(plugin:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) PVASDKKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface PVASDKKtor_utilsAttributeKey<T> : PVASDKBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString *)name type:(PVASDKKtor_utilsTypeInfo *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (PVASDKKtor_utilsAttributeKey<T> *)doCopyName:(NSString *)name type:(PVASDKKtor_utilsTypeInfo *)type __attribute__((swift_name("doCopy(name:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Ktor_eventsEventDefinition")))
@interface PVASDKKtor_eventsEventDefinition<T> : PVASDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface PVASDKKtor_utilsPipelinePhase : PVASDKBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol PVASDKKotlinSuspendFunction2 <PVASDKKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface PVASDKKtor_client_coreHttpReceivePipelinePhases : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface PVASDKKotlinUnit : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface PVASDKKtor_client_coreHttpRequestPipelinePhases : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol PVASDKKtor_httpHttpMessageBuilder
@required
@property (readonly) PVASDKKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface PVASDKKtor_client_coreHttpRequestBuilder : PVASDKBase <PVASDKKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) PVASDKKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<PVASDKKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<PVASDKKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<PVASDKKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (PVASDKKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(PVASDKKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (PVASDKKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(PVASDKKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(PVASDKKtor_httpURLBuilder *, PVASDKKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<PVASDKKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property PVASDKKtor_utilsTypeInfo * _Nullable bodyType __attribute__((swift_name("bodyType")));
@property (readonly) id<PVASDKKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) PVASDKKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property PVASDKKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) PVASDKKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface PVASDKKtor_client_coreHttpResponsePipelinePhases : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface PVASDKKtor_client_coreHttpResponseContainer : PVASDKBase
- (instancetype)initWithExpectedType:(PVASDKKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (PVASDKKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(PVASDKKtor_utilsTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) PVASDKKtor_utilsTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface PVASDKKtor_client_coreHttpSendPipelinePhases : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) PVASDKKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol PVASDKKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<PVASDKKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PVASDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<PVASDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) PVASDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface PVASDKKotlinx_serialization_coreSerializersModule : PVASDKBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<PVASDKKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PVASDKKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<PVASDKKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<PVASDKKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PVASDKKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PVASDKKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<PVASDKKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<PVASDKKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol PVASDKKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface PVASDKKotlinx_serialization_coreSerialKind : PVASDKBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol PVASDKKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<PVASDKKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<PVASDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) PVASDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface PVASDKKotlinNothing : PVASDKBase
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol PVASDKKotlinx_coroutines_coreParentJob <PVASDKKotlinx_coroutines_coreJob>
@required

/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
- (PVASDKKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end


/**
 * @note annotations
 *   kotlinx.coroutines.InternalCoroutinesApi
*/
__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol PVASDKKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnCompletionDisposableHandle:(id<PVASDKKotlinx_coroutines_coreDisposableHandle>)disposableHandle __attribute__((swift_name("disposeOnCompletion(disposableHandle:)")));
- (void)selectInRegistrationPhaseInternalResult:(id _Nullable)internalResult __attribute__((swift_name("selectInRegistrationPhase(internalResult:)")));
- (BOOL)trySelectClauseObject:(id)clauseObject result:(id _Nullable)result __attribute__((swift_name("trySelect(clauseObject:result:)")));
@property (readonly) id<PVASDKKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end

__attribute__((swift_name("Ktor_ioJvmSerializable")))
@protocol PVASDKKtor_ioJvmSerializable
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=io/ktor/http/UrlSerializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface PVASDKKtor_httpUrl : PVASDKBase <PVASDKKtor_ioJvmSerializable>
@property (class, readonly, getter=companion) PVASDKKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property (readonly) NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *encodedPathAndQuery __attribute__((swift_name("encodedPathAndQuery")));
@property (readonly) NSString *encodedQuery __attribute__((swift_name("encodedQuery")));
@property (readonly) NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<PVASDKKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments"))) __attribute__((deprecated("\n        `pathSegments` is deprecated.\n\n        This property will contain an empty path segment at the beginning for URLs with a hostname,\n        and an empty path segment at the end for the URLs with a trailing slash. If you need to keep this behaviour please\n        use [rawSegments]. If you only need to access the meaningful parts of the path, consider using [segments] instead.\n             \n        Please decide if you need [rawSegments] or [segments] explicitly.\n        ")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) PVASDKKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) PVASDKKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property (readonly) NSArray<NSString *> *rawSegments __attribute__((swift_name("rawSegments")));
@property (readonly) NSArray<NSString *> *segments __attribute__((swift_name("segments")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface PVASDKKtor_httpHttpMethod : PVASDKBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface PVASDKKtor_httpOutgoingContent : PVASDKBase
- (id _Nullable)getPropertyKey:(PVASDKKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(PVASDKKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
- (id<PVASDKKtor_httpHeaders> _Nullable)trailers __attribute__((swift_name("trailers()")));
@property (readonly) PVASDKLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) PVASDKKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<PVASDKKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) PVASDKKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol PVASDKKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol PVASDKKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol PVASDKKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol PVASDKKotlinKClass <PVASDKKotlinKDeclarationContainer, PVASDKKotlinKAnnotatedElement, PVASDKKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinKType")))
@protocol PVASDKKotlinKType
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) NSArray<PVASDKKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
@property (readonly) id<PVASDKKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface PVASDKKotlinByteArray : PVASDKBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(PVASDKByte *(^)(PVASDKInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (PVASDKKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_io_coreRawSink")))
@protocol PVASDKKotlinx_io_coreRawSink <PVASDKKotlinAutoCloseable>
@required
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeSource:(PVASDKKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
@end

__attribute__((swift_name("Kotlinx_io_coreSink")))
@protocol PVASDKKotlinx_io_coreSink <PVASDKKotlinx_io_coreRawSink>
@required
- (void)emit __attribute__((swift_name("emit()")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (int64_t)transferFromSource:(id<PVASDKKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (void)writeSource:(id<PVASDKKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(PVASDKKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) PVASDKKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_io_coreBuffer")))
@interface PVASDKKotlinx_io_coreBuffer : PVASDKBase <PVASDKKotlinx_io_coreSource, PVASDKKotlinx_io_coreSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (PVASDKKotlinx_io_coreBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (void)doCopyToOut:(PVASDKKotlinx_io_coreBuffer *)out startIndex:(int64_t)startIndex endIndex:(int64_t)endIndex __attribute__((swift_name("doCopyTo(out:startIndex:endIndex:)")));
- (void)emit __attribute__((swift_name("emit()")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (void)flush __attribute__((swift_name("flush()")));
- (int8_t)getPosition:(int64_t)position __attribute__((swift_name("get(position:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
- (void)hintEmit __attribute__((swift_name("hintEmit()")));
- (id<PVASDKKotlinx_io_coreSource>)peek __attribute__((swift_name("peek()")));
- (int64_t)readAtMostToSink:(PVASDKKotlinx_io_coreBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readAtMostTo(sink:byteCount:)")));
- (int32_t)readAtMostToSink:(PVASDKKotlinByteArray *)sink startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("readAtMostTo(sink:startIndex:endIndex:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (void)readToSink:(id<PVASDKKotlinx_io_coreRawSink>)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readTo(sink:byteCount:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int64_t)transferFromSource:(id<PVASDKKotlinx_io_coreRawSource>)source __attribute__((swift_name("transferFrom(source:)")));
- (int64_t)transferToSink:(id<PVASDKKotlinx_io_coreRawSink>)sink __attribute__((swift_name("transferTo(sink:)")));
- (void)writeSource:(PVASDKKotlinx_io_coreBuffer *)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (void)writeSource:(id<PVASDKKotlinx_io_coreRawSource>)source byteCount_:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount_:)")));
- (void)writeSource:(PVASDKKotlinByteArray *)source startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("write(source:startIndex:endIndex:)")));
- (void)writeByteByte:(int8_t)byte __attribute__((swift_name("writeByte(byte:)")));
- (void)writeIntInt:(int32_t)int_ __attribute__((swift_name("writeInt(int:)")));
- (void)writeLongLong:(int64_t)long_ __attribute__((swift_name("writeLong(long:)")));
- (void)writeShortShort:(int16_t)short_ __attribute__((swift_name("writeShort(short:)")));

/**
 * @note annotations
 *   kotlinx.io.InternalIoApi
*/
@property (readonly) PVASDKKotlinx_io_coreBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface PVASDKKtor_utilsWeekDayCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (PVASDKKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface PVASDKKtor_utilsMonthCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (PVASDKKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol PVASDKKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<PVASDKKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface PVASDKKotlinAbstractCoroutineContextKey<B, E> : PVASDKBase <PVASDKKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<PVASDKKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<PVASDKKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface PVASDKKotlinx_coroutines_coreCoroutineDispatcherKey : PVASDKKotlinAbstractCoroutineContextKey<id<PVASDKKotlinContinuationInterceptor>, PVASDKKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<PVASDKKotlinCoroutineContextKey>)baseKey safeCast:(id<PVASDKKotlinCoroutineContextElement> _Nullable (^)(id<PVASDKKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol PVASDKKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@protocol PVASDKKtor_utilsStringValuesBuilder
@required
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<PVASDKKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<PVASDKKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<PVASDKKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<PVASDKKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end

__attribute__((swift_name("Ktor_utilsStringValuesBuilderImpl")))
@interface PVASDKKtor_utilsStringValuesBuilderImpl : PVASDKBase <PVASDKKtor_utilsStringValuesBuilder>
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<PVASDKKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<PVASDKKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<PVASDKKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<PVASDKKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) PVASDKMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface PVASDKKtor_httpHeadersBuilder : PVASDKKtor_utilsStringValuesBuilderImpl
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<PVASDKKtor_httpHeaders>)build __attribute__((swift_name("build()")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface PVASDKKtor_client_coreHttpRequestBuilderCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface PVASDKKtor_httpURLBuilder : PVASDKBase
- (instancetype)initWithProtocol:(PVASDKKtor_httpURLProtocol * _Nullable)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password pathSegments:(NSArray<NSString *> *)pathSegments parameters:(id<PVASDKKtor_httpParameters>)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:pathSegments:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *encodedFragment __attribute__((swift_name("encodedFragment")));
@property id<PVASDKKtor_httpParametersBuilder> encodedParameters __attribute__((swift_name("encodedParameters")));
@property NSString * _Nullable encodedPassword __attribute__((swift_name("encodedPassword")));
@property NSArray<NSString *> *encodedPathSegments __attribute__((swift_name("encodedPathSegments")));
@property NSString * _Nullable encodedUser __attribute__((swift_name("encodedUser")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) id<PVASDKKtor_httpParametersBuilder> parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSArray<NSString *> *pathSegments __attribute__((swift_name("pathSegments")));
@property int32_t port __attribute__((swift_name("port")));
@property PVASDKKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property PVASDKKtor_httpURLProtocol * _Nullable protocolOrNull __attribute__((swift_name("protocolOrNull")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol PVASDKKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<PVASDKKotlinKClass>)kClass provider:(id<PVASDKKotlinx_serialization_coreKSerializer> (^)(NSArray<id<PVASDKKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<PVASDKKotlinKClass>)kClass serializer:(id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<PVASDKKotlinKClass>)baseClass actualClass:(id<PVASDKKotlinKClass>)actualClass actualSerializer:(id<PVASDKKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<PVASDKKotlinKClass>)baseClass defaultDeserializerProvider:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<PVASDKKotlinKClass>)baseClass defaultDeserializerProvider:(id<PVASDKKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<PVASDKKotlinKClass>)baseClass defaultSerializerProvider:(id<PVASDKKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface PVASDKKtor_httpUrlCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
- (id<PVASDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("Ktor_httpParameters")))
@protocol PVASDKKtor_httpParameters <PVASDKKtor_utilsStringValues>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface PVASDKKtor_httpURLProtocol : PVASDKBase <PVASDKKtor_ioJvmSerializable>
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface PVASDKKtor_httpHttpMethodCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<PVASDKKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) PVASDKKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) PVASDKKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) PVASDKKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) PVASDKKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) PVASDKKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) PVASDKKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) PVASDKKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface PVASDKKtor_httpHeaderValueWithParameters : PVASDKBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<PVASDKKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<PVASDKKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface PVASDKKtor_httpContentType : PVASDKKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<PVASDKKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<PVASDKKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) PVASDKKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(PVASDKKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (PVASDKKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (PVASDKKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface PVASDKKotlinKTypeProjection : PVASDKBase
- (instancetype)initWithVariance:(PVASDKKotlinKVariance * _Nullable)variance type:(id<PVASDKKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) PVASDKKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (PVASDKKotlinKTypeProjection *)doCopyVariance:(PVASDKKotlinKVariance * _Nullable)variance type:(id<PVASDKKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<PVASDKKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) PVASDKKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface PVASDKKotlinByteIterator : PVASDKBase <PVASDKKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (PVASDKByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface PVASDKKtor_httpURLBuilderCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Ktor_httpParametersBuilder")))
@protocol PVASDKKtor_httpParametersBuilder <PVASDKKtor_utilsStringValuesBuilder>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface PVASDKKtor_httpURLProtocolCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) PVASDKKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) PVASDKKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) PVASDKKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) PVASDKKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) PVASDKKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, PVASDKKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface PVASDKKtor_httpHeaderValueParam : PVASDKBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("init(name:value:escapeValue:)"))) __attribute__((objc_designated_initializer));
- (PVASDKKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value escapeValue:(BOOL)escapeValue __attribute__((swift_name("doCopy(name:value:escapeValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL escapeValue __attribute__((swift_name("escapeValue")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface PVASDKKtor_httpHeaderValueWithParametersCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<PVASDKKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface PVASDKKtor_httpContentTypeCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (PVASDKKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) PVASDKKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface PVASDKKotlinKVariance : PVASDKKotlinEnum<PVASDKKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) PVASDKKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) PVASDKKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) PVASDKKotlinKVariance *out __attribute__((swift_name("out")));
+ (PVASDKKotlinArray<PVASDKKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<PVASDKKotlinKVariance *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface PVASDKKotlinKTypeProjectionCompanion : PVASDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) PVASDKKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (PVASDKKotlinKTypeProjection *)contravariantType:(id<PVASDKKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (PVASDKKotlinKTypeProjection *)covariantType:(id<PVASDKKotlinKType>)type __attribute__((swift_name("covariant(type:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (PVASDKKotlinKTypeProjection *)invariantType:(id<PVASDKKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) PVASDKKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
